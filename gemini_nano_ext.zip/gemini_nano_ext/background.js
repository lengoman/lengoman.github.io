
chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error(error));

chrome.runtime.onInstalled.addListener(() => {

  console.log("Extension ID:", chrome.runtime.id);

  chrome.action.onClicked.addListener((tab) => {
    console.log("Action button clicked", tab);
    chrome.tabs.sendMessage(tab.id, {action: "getPageContent"});
  });

// content.js
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Content script received message:",request)
    if (request.action === "getPageContent") {
      const pageContent = document.body.innerText;
      console.log("Content script: Page content:", pageContent);
      chrome.runtime.sendMessage({action: "pageContent", content: pageContent});
    }
  });
});